package io.chronosphere;

import java.util.Set;

/**
 * Contains the list of valid dog breeds supported by the dog.ceo API.
 * 
 * This is used to validate user input before making API requests,
 * preventing unnecessary calls for invalid breed names.
 */
public class Breeds {
    
    /**
     * Immutable set of all valid breed names.
     * These correspond to the top-level breeds available at dog.ceo/api.
     */
    public static final Set<String> BREEDS = Set.of(
        "affenpinscher",
        "african",
        "airedale",
        "akita",
        "appenzeller",
        "australian",
        "basenji",
        "beagle",
        "bluetick",
        "borzoi",
        "bouvier",
        "boxer",
        "brabancon",
        "briard",
        "buhund",
        "bulldog",
        "bullterrier",
        "cattledog",
        "cavapoo",
        "chihuahua",
        "chow",
        "clumber",
        "cockapoo",
        "collie",
        "coonhound",
        "corgi",
        "cotondetulear",
        "dachshund",
        "dalmatian",
        "dane",
        "deerhound",
        "dhole",
        "dingo",
        "doberman",
        "elkhound",
        "entlebucher",
        "eskimo",
        "finnish",
        "frise",
        "germanshepherd",
        "greyhound",
        "groenendael",
        "havanese",
        "hound",
        "husky",
        "keeshond",
        "kelpie",
        "komondor",
        "kuvasz",
        "labradoodle",
        "labrador",
        "leonberg",
        "lhasa",
        "malamute",
        "malinois",
        "maltese",
        "mastiff",
        "mexicanhairless",
        "mix",
        "mountain",
        "newfoundland",
        "otterhound",
        "ovcharka",
        "papillon",
        "pekinese",
        "pembroke",
        "pinscher",
        "pitbull",
        "pointer",
        "pomeranian",
        "poodle",
        "pug",
        "puggle",
        "pyrenees",
        "redbone",
        "retriever",
        "ridgeback",
        "rottweiler",
        "saluki",
        "samoyed",
        "schipperke",
        "schnauzer",
        "segugio",
        "setter",
        "sharpei",
        "sheepdog",
        "shiba",
        "shihtzu",
        "spaniel",
        "spitz",
        "springer",
        "stbernard",
        "terrier",
        "tervuren",
        "vizsla",
        "waterdog",
        "weimaraner",
        "whippet",
        "wolfhound"
    );

    /**
     * Checks if a breed name is valid (case-insensitive).
     * 
     * @param breed The breed name to validate
     * @return true if the breed is valid, false otherwise
     */
    public static boolean isValidBreed(String breed) {
        return BREEDS.contains(breed.toLowerCase());
    }
}
