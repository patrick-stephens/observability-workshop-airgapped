package io.chronosphere;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.javalin.Javalin;
import io.javalin.http.Context;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// =============================================================================
// LAB 2 - WORKSHOP REFERENCE CODE 
// Uncommenting adds import to access the current span from automatic instrumentation:
//
// import io.opentelemetry.api.trace.Span;
// =============================================================================

// =============================================================================
// LAB 6 - WORKSHOP REFERENCE CODE 
// Uncommenting adds imports for OpenTelemetry metrics API:
//
// import io.opentelemetry.api.OpenTelemetry;
// import io.opentelemetry.api.common.Attributes;
// import io.opentelemetry.api.common.AttributeKey;
// import io.opentelemetry.api.metrics.DoubleHistogram;
// import io.opentelemetry.api.metrics.LongCounter;
// import io.opentelemetry.api.metrics.Meter;
// import io.opentelemetry.api.trace.Tracer;
// import io.opentelemetry.exporter.prometheus.PrometheusHttpServer;
// import io.opentelemetry.sdk.OpenTelemetrySdk;
// import io.opentelemetry.sdk.metrics.SdkMeterProvider;
// import io.opentelemetry.sdk.resources.Resource;
// import io.opentelemetry.sdk.trace.SdkTracerProvider;
// import io.opentelemetry.semconv.ResourceAttributes;
// =============================================================================

/**
 * Main application class for the Java Instrumentation Demo.
 * 
 * This is a simple HTTP server built using Javalin.
 * It provides endpoints for demonstrating OpenTelemetry instrumentation.
 * 
 * Endpoints:
 * - GET  /         : Page view counter
 * - GET  /rolldice : Random dice roll (1-6)
 * - GET  /doggo    : Random dog image from dog.ceo API
 * - POST /doggo    : Search for specific breed image
 */
public class App {

    /** Port the HTTP server listens on */
    private static final int PORT = 9999;
    
    /** Thread-safe counter for page views */
    private static final AtomicInteger HITS = new AtomicInteger(0);
    
    /** Random number generator for dice rolls */
    private static final Random RANDOM = new Random();

    /** Pattern to extract breed name from dog.ceo image URLs */
    private static final Pattern BREED_PATTERN = Pattern.compile("/breeds/([^/]+)/");

    // =========================================================================
    // LAB 6 - WORKSHOP REFERENCE CODE 
    // Uncomment the following to initialize OpenTelemetry and get a Tracer and Meter:
    //
    // private static final OpenTelemetry openTelemetry = initOpenTelemetry();
    // private static final Tracer tracer = openTelemetry
    //     .getTracer("io.chronosphere.App");
    // private static final Meter meter = openTelemetry
    //     .getMeter("io.chronosphere.App");
    // =========================================================================

    // =========================================================================
    // LAB 6 - WORKSHOP REFERENCE CODE 
    // Uncomment the following to use counter and histogram metrics for pages and requests:
    //
    // /** Counter for tracking homepage hits */
    // private static final LongCounter hitsCounter = meter
    //     .counterBuilder("app_hits_total")
    //     .setDescription("Total number of homepage hits")
    //     .setUnit("1")
    //     .build();
    //
    // /** Histogram for tracking request duration */
    // private static final DoubleHistogram requestDuration = meter
    //     .histogramBuilder("http_request_duration_seconds")
    //     .setDescription("HTTP request duration in seconds")
    //     .setUnit("s")
    //     .build();
    // =========================================================================

    // =========================================================================
    // LAB 6 - WORKSHOP REFERENCE CODE 
    // Uncomment the following to initialize OpenTelemetry SDK with Prometheus metrics:
    //
    // @SuppressWarnings("deprecation")
    // private static OpenTelemetry initOpenTelemetry() {
    //     Resource resource = Resource.getDefault()
    //         .merge(Resource.create(Attributes.of(
    //             ResourceAttributes.SERVICE_NAME, "java-demo")));
    // 
    //     // Configure tracer provider
    //     SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
    //         .setResource(resource)
    //         .build();
    // 
    //     // Configure Prometheus HTTP server on port 9464
    //     SdkMeterProvider meterProvider = SdkMeterProvider.builder()
    //         .setResource(resource)
    //         .registerMetricReader(PrometheusHttpServer.builder()
    //             .setPort(9464)
    //             .build())
    //         .build();
    // 
    //     return OpenTelemetrySdk.builder()
    //         .setTracerProvider(tracerProvider)
    //         .setMeterProvider(meterProvider)
    //         .buildAndRegisterGlobal();
    // }
    // =========================================================================

    /**
     * Application entry point. Creates and starts the HTTP server.
     */
    public static void main(String[] args) {
        Javalin app = createApp();
        app.start(PORT);
    }

    /**
     * Creates and configures the Javalin application.
     * Separated for testability.
     */
    public static Javalin createApp() {
        Javalin app = Javalin.create();
        
        app.events(event -> {
            event.serverStarted(() -> {
                System.out.println("Server started on http://localhost:" + PORT);
            });
        });
        
        // Register endpoint handlers
        app.get("/", App::handleIndex);
        app.get("/rolldice", App::handleRollDice);
        app.get("/doggo", App::handleDoggoGet);
        app.post("/doggo", App::handleDoggoPost);
        
        return app;
    }

    /**
     * Handler for the index page (/).
     * Tracks and displays the number of times the page has been viewed.
     */
    private static void handleIndex(Context ctx) {
        
        int hits = HITS.incrementAndGet();
        
        // =========================================================================
        // LAB 2 - WORKSHOP REFERENCE CODE 
        // Uncomment the following to add custom attributes to auto-instrumented spans:
        //
        // // Get the current span created by the agent
        // Span span = Span.current();
        //    
        // // Add custom attribute to the span
        // span.setAttribute("app.hits", hits);
        // =========================================================================

        // =========================================================================
        // LAB 6 - WORKSHOP REFERENCE CODE 
        // Uncomment the following to increment the counter with attributes:
        // 
        // Increment the counter with attributes
        // hitsCounter.add(1, Attributes.of(
        //     AttributeKey.stringKey("endpoint"), "/"));
        // =========================================================================
        
        ctx.contentType("text/plain");
        ctx.result("This webpage has been viewed " + hits + " times");
    }

    /**
     * Handler for the dice roll endpoint (/rolldice).
     * Returns a random number between 1 and 6.
     */
    private static void handleRollDice(Context ctx) {
        int roll = RANDOM.nextInt(6) + 1;
        ctx.contentType("text/plain");
        ctx.result(String.valueOf(roll));
    }

    /**
     * Handler for GET /doggo.
     * Fetches a random dog image from the dog.ceo API.
     */
    private static void handleDoggoGet(Context ctx) {
        // =====================================================================
        // LAB 6 - WORKSHOP REFERENCE CODE 
        // Uncomment the following to track request duration with histogram:
        //
        // long startTime = System.nanoTime();
        // =====================================================================
        try {
            String apiUrl = "https://dog.ceo/api/breeds/image/random";
            JsonObject json = fetchJson(apiUrl);
            String imageSrc = json.get("message").getAsString();
            String breed = extractBreedFromUrl(imageSrc);
            
            String html = renderTemplate(imageSrc, breed, null);
            ctx.contentType("text/html");
            ctx.result(html);
        } catch (Exception e) {
            ctx.contentType("text/html");
            ctx.status(500);
            ctx.result(renderTemplateQuiet(null, null, "Error: " + e.getMessage()));
        }
        // =====================================================================
        // LAB 6 - WORKSHOP REFERENCE CODE 
        // Uncomment the following (with startTime above) to record request duration:
        //
        // finally {
        //     double duration = (System.nanoTime() - startTime) / 1_000_000_000.0;
        //     requestDuration.record(duration, Attributes.of(
        //         AttributeKey.stringKey("endpoint"), "/doggo"));
        // }
        // =====================================================================
    }

    /**
     * Handler for POST /doggo.
     * Searches for a specific breed image.
     */
    private static void handleDoggoPost(Context ctx) {
        // =====================================================================
        // LAB 6 - WORKSHOP REFERENCE CODE 
        // Uncomment the following to track request duration with histogram:
        //
        // long startTime = System.nanoTime();
        // =====================================================================
        try {
            String breed = ctx.formParam("breed-search");
            String imageSrc;
            String error = null;
            
            if (breed == null || breed.isEmpty()) {
                error = "No breed specified.";
                imageSrc = null;
            } else if (!Breeds.isValidBreed(breed)) {
                error = "No breed found.";
                imageSrc = null;
            } else {
                String apiUrl = "https://dog.ceo/api/breed/" + breed + "/images/random";
                JsonObject json = fetchJson(apiUrl);
                imageSrc = json.get("message").getAsString();
            }
            
            String html = renderTemplate(imageSrc, breed, error);
            ctx.contentType("text/html");
            ctx.result(html);
        } catch (Exception e) {
            ctx.contentType("text/html");
            ctx.status(500);
            ctx.result(renderTemplateQuiet(null, null, "Error: " + e.getMessage()));
        }
        // =====================================================================
        // LAB 6 - WORKSHOP REFERENCE CODE 
        // Uncomment the following (with startTime above) to record request duration:
        //
        // finally {
        //     double duration = (System.nanoTime() - startTime) / 1_000_000_000.0;
        //     requestDuration.record(duration, Attributes.of(
        //         AttributeKey.stringKey("endpoint"), "/doggo"));
        // }
        // =====================================================================
    }

    /**
     * Fetches JSON from a URL using HttpURLConnection.
     */
    private static JsonObject fetchJson(String urlString) throws IOException {
        URL url = URI.create(urlString).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            return JsonParser.parseString(response.toString()).getAsJsonObject();
        } finally {
            conn.disconnect();
        }
    }

    /**
     * Extracts the breed name from a dog.ceo image URL.
     */
    private static String extractBreedFromUrl(String imageUrl) {
        Matcher matcher = BREED_PATTERN.matcher(imageUrl);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "unknown";
    }

    /**
     * Renders the HTML template with the dog image or error message.
     */
    private static String renderTemplate(String imageSrc, String breed, String error) throws IOException {
        String template = loadTemplate();
        
        String content;
        if (error != null) {
            content = "<p>Ruh-roh. " + escapeHtml(error) + "</p>";
        } else {
            content = "<img id=\"picture\" src=\"" + escapeHtml(imageSrc) + "\" alt=\"dog photo returned from API\">\n" +
                     "<h2>Breed: " + escapeHtml(breed) + "</h2>";
        }
        
        return template.replace("{{CONTENT}}", content);
    }

    /**
     * Renders template without throwing (for error handling).
     */
    private static String renderTemplateQuiet(String imageSrc, String breed, String error) {
        try {
            return renderTemplate(imageSrc, breed, error);
        } catch (IOException e) {
            return "<html><body><p>Ruh-roh. " + escapeHtml(error) + "</p></body></html>";
        }
    }

    /**
     * Loads the HTML template from the classpath resources.
     */
    private static String loadTemplate() throws IOException {
        try (InputStream is = App.class.getResourceAsStream("/templates/random-pet-pic.html")) {
            if (is == null) {
                throw new IOException("Template not found");
            }
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * Escapes HTML special characters to prevent XSS.
     */
    private static String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                  .replace("<", "&lt;")
                  .replace(">", "&gt;")
                  .replace("\"", "&quot;");
    }
}
