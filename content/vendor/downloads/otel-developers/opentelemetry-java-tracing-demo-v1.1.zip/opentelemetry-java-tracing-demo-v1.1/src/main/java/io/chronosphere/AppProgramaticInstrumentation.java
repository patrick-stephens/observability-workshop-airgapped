package io.chronosphere;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.javalin.Javalin;
import io.javalin.http.Context;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// =============================================================================
// LAB 3 - WORKSHOP REFERENCE CODE 
// Uncomment the following imports for programmatic OpenTelemetry instrumentation:
//
// import io.opentelemetry.api.OpenTelemetry;
// import io.opentelemetry.api.common.Attributes;
// import io.opentelemetry.api.trace.Tracer;
// import io.opentelemetry.sdk.OpenTelemetrySdk;
// import io.opentelemetry.sdk.resources.Resource;
// import io.opentelemetry.sdk.trace.SdkTracerProvider;
// import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;
// import io.opentelemetry.exporter.logging.LoggingSpanExporter;
// import io.opentelemetry.semconv.ServiceAttributes;
// import io.opentelemetry.api.trace.Span;
// import io.opentelemetry.api.trace.SpanKind;
// import io.opentelemetry.api.trace.StatusCode;
// import io.opentelemetry.context.Scope;
// import io.opentelemetry.exporter.otlp.trace.OtlpGrpcSpanExporter;
// =============================================================================

// =============================================================================
// LAB 5 - WORKSHOP REFERENCE CODE 
// 
// Manual Instrumentation:
// Uncomment the following imports for manual OpenTelemetry instrumentation:
//
// import io.opentelemetry.api.trace.Span;
// import io.opentelemetry.api.GlobalOpenTelemetry;
// import io.opentelemetry.api.trace.Tracer;
// import io.opentelemetry.context.Scope;
// import io.opentelemetry.api.common.Attributes;
// import io.opentelemetry.api.trace.StatusCode;
// =============================================================================

/**
 * Main application class for the Java ProgramaticInstrumentation Demo.
 * 
 * This is a simple HTTP server built using Javalin.
 * It provides endpoints for demonstrating OpenTelemetry instrumentation.
 * 
 * Endpoints:
 * - GET  /         : Page view counter
 * - GET  /rolldice : Random dice roll (1-6)
 * - GET  /doggo    : Random dog image from dog.ceo API
 * - POST /doggo    : Search for specific breed image
 */
public class AppProgramaticInstrumentation {

    /** Port the HTTP server listens on */
    private static final int PORT = 9999;
    
    /** Thread-safe counter for page views */
    private static final AtomicInteger HITS = new AtomicInteger(0);
    
    /** Random number generator for dice rolls */
    private static final Random RANDOM = new Random();

    /** Pattern to extract breed name from dog.ceo image URLs */
    private static final Pattern BREED_PATTERN = Pattern.compile("/breeds/([^/]+)/");

    // =========================================================================
    // LAB 3 - WORKSHOP REFERENCE CODE 
    // Uncomment the following to initialize OpenTelemetry and get a Tracer:
    //
    // private static final OpenTelemetry openTelemetry = initOpenTelemetry();
    // private static final Tracer tracer = openTelemetry
    //     .getTracer("io.chronosphere.AppProgramaticInstrumentation", "1.0.0");
    // =========================================================================

    // =========================================================================
    // LAB 5 - WORKSHOP REFERENCE CODE 
    // When using the Java Agent, get a tracer from GlobalOpenTelemetry:
    //
    // private static final Tracer tracer = GlobalOpenTelemetry
    //     .getTracer("io.chronosphere.AppProgramaticInstrumentation", "1.0.0");
    // =========================================================================

    // =========================================================================
    // LAB 3 - WORKSHOP REFERENCE CODE 
    // Uncomment the following to initialize OpenTelemetry SDK programmatically:
    //
    // private static OpenTelemetry initOpenTelemetry() {
    //     Resource resource = Resource.getDefault()
    //         .merge(Resource.create(Attributes.of(
    //             ServiceAttributes.SERVICE_NAME, "java-demo")));
    // 
    //     SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
    //         .setResource(resource)
    //         .addSpanProcessor(SimpleSpanProcessor.create(
    //             LoggingSpanExporter.create()))
    //         .build();
    // 
    //     return OpenTelemetrySdk.builder()
    //         .setTracerProvider(tracerProvider)
    //         .buildAndRegisterGlobal();
    // }
    // =========================================================================

    // =========================================================================
    // LAB 3 - WORKSHOP REFERENCE CODE 
    // To send spans to Jaeger, replace initOpenTelemetry() with this version:
    //
    // private static OpenTelemetry initOpenTelemetry() {
    //     Resource resource = Resource.getDefault()
    //         .merge(Resource.create(Attributes.of(
    //             ServiceAttributes.SERVICE_NAME, "java-demo")));
    // 
    //     OtlpGrpcSpanExporter otlpExporter = OtlpGrpcSpanExporter.builder()
    //         .setEndpoint("http://localhost:4317")
    //         .build();
    // 
    //     SdkTracerProvider tracerProvider = SdkTracerProvider.builder()
    //         .setResource(resource)
    //         .addSpanProcessor(SimpleSpanProcessor.create(otlpExporter))
    //         .build();
    // 
    //     return OpenTelemetrySdk.builder()
    //         .setTracerProvider(tracerProvider)
    //         .buildAndRegisterGlobal();
    // }
    // =========================================================================

    /**
     * Application entry point. Creates and starts the HTTP server.
     */
    public static void main(String[] args) {
        Javalin app = createApp();
        app.start(PORT);
    }

    /**
     * Creates and configures the Javalin application.
     * Separated for testability.
     */
    public static Javalin createApp() {
        Javalin app = Javalin.create();
        
        app.events(event -> {
            event.serverStarted(() -> {
                System.out.println("Server started on http://localhost:" + PORT);
            });
        });
        
        // Register endpoint handlers
        app.get("/", AppProgramaticInstrumentation::handleIndex);
        app.get("/rolldice", AppProgramaticInstrumentation::handleRollDice);
        app.get("/doggo", AppProgramaticInstrumentation::handleDoggoGet);
        app.post("/doggo", AppProgramaticInstrumentation::handleDoggoPost);
        
        return app;
    }

    /**
     * Handler for the index page (/).
     * Tracks and displays the number of times the page has been viewed.
     */
    private static void handleIndex(Context ctx) {
        
        int hits = HITS.incrementAndGet();
        
        ctx.contentType("text/plain");
        ctx.result("This webpage has been viewed " + hits + " times");
        
        // =====================================================================
        // LAB 3 - WORKSHOP REFERENCE CODE 
        // Replace the code above with the following to instrument with a span:
        //
        // Span span = tracer.spanBuilder("handleIndex")
        //     .setSpanKind(SpanKind.SERVER)
        //     .startSpan();
        // 
        // try (Scope scope = span.makeCurrent()) {
        //     span.setAttribute("app.hits", hits);
        // 
        //     ctx.contentType("text/plain");
        //     ctx.result("This webpage has been viewed " + hits + " times");
        // } finally {
        //     span.end();
        // }
        // =====================================================================

        // =========================================================================
        // LAB 5 - WORKSHOP REFERENCE CODE 
        // 
        // Manual Instrumentation:
        // Uncomment the following to add custom attributes to auto-instrumented spans:
        //
        // // Get the current span created by the agent
        // Span span = Span.current();
        //    
        // // Add custom attributes to the span
        // span.setAttribute("app.hits", hits);
        // span.setAttribute("app.endpoint", "/");
        // =========================================================================
    }

    /**
     * Handler for the dice roll endpoint (/rolldice).
     * Returns a random number between 1 and 6.
     */
    private static void handleRollDice(Context ctx) {
        
        int roll = RANDOM.nextInt(6) + 1;

        // =========================================================================
        // LAB 5 - WORKSHOP REFERENCE CODE 
        // Uncomment the following to add custom event to auto-instrumented span logs:
        //
        // Span span = Span.current();
        //
        // span.addEvent("dice_rolled", Attributes.builder()
        //     .put("result", (long) roll)
        //     .build());
        // =========================================================================

        ctx.contentType("text/plain");
        ctx.result(String.valueOf(roll));
    }

    /**
     * Handler for GET /doggo.
     * Fetches a random dog image from the dog.ceo API.
     */
    private static void handleDoggoGet(Context ctx) {
        try {
            String apiUrl = "https://dog.ceo/api/breeds/image/random";
            JsonObject json = fetchJson(apiUrl);
            String imageSrc = json.get("message").getAsString();
            String breed = extractBreedFromUrl(imageSrc);
            
            String html = renderTemplate(imageSrc, breed, null);
            ctx.contentType("text/html");
            ctx.result(html);
        } catch (Exception e) {
            ctx.contentType("text/html");
            ctx.status(500);
            ctx.result(renderTemplateQuiet(null, null, "Error: " + e.getMessage()));
        }
        
        // =====================================================================
        // LAB 3 - WORKSHOP REFERENCE CODE 
        // Replace the code above with the following to instrument with spans:
        //
        // Span parentSpan = tracer.spanBuilder("handleDoggoGet")
        //     .setSpanKind(SpanKind.SERVER)
        //     .startSpan();
        // 
        // try (Scope parentScope = parentSpan.makeCurrent()) {
        //     // Child span for API call
        //     String apiUrl = "https://dog.ceo/api/breeds/image/random";
        //     parentSpan.setAttribute("http.url", apiUrl);
        // 
        //     Span fetchSpan = tracer.spanBuilder("fetchJson")
        //         .setSpanKind(SpanKind.CLIENT)
        //         .startSpan();
        // 
        //     JsonObject json;
        //     try (Scope fetchScope = fetchSpan.makeCurrent()) {
        //         fetchSpan.setAttribute("http.method", "GET");
        //         fetchSpan.setAttribute("http.url", apiUrl);
        //         json = fetchJson(apiUrl);
        //         fetchSpan.setAttribute("http.status_code", 200);
        //     } finally {
        //         fetchSpan.end();
        //     }
        // 
        //     String imageSrc = json.get("message").getAsString();
        // 
        //     // Child span for breed extraction
        //     Span extractSpan = tracer.spanBuilder("extractBreed")
        //         .setSpanKind(SpanKind.INTERNAL)
        //         .startSpan();
        // 
        //     String breed;
        //     try (Scope extractScope = extractSpan.makeCurrent()) {
        //         breed = extractBreedFromUrl(imageSrc);
        //         extractSpan.setAttribute("app.breed", breed);
        //     } finally {
        //         extractSpan.end();
        //     }
        // 
        //     // Child span for template rendering
        //     Span renderSpan = tracer.spanBuilder("renderTemplate")
        //         .setSpanKind(SpanKind.INTERNAL)
        //         .startSpan();
        // 
        //     String html;
        //     try (Scope renderScope = renderSpan.makeCurrent()) {
        //         html = renderTemplate(imageSrc, breed, null);
        //     } finally {
        //         renderSpan.end();
        //     }
        // 
        //     parentSpan.setAttribute("app.breed", breed);
        //     ctx.contentType("text/html");
        //     ctx.result(html);
        // 
        // } catch (Exception e) {
        //     parentSpan.setStatus(StatusCode.ERROR, e.getMessage());
        //     parentSpan.recordException(e);
        //     ctx.contentType("text/html");
        //     ctx.status(500);
        //     ctx.result(renderTemplateQuiet(null, null, "Error: " + e.getMessage()));
        // } finally {
        //     parentSpan.end();
        // }
        // =====================================================================
    }

    /**
     * Handler for POST /doggo.
     * Searches for a specific breed image.
     */
    private static void handleDoggoPost(Context ctx) {
        try {
            String breed = ctx.formParam("breed-search");
            String imageSrc;
            String error = null;
            
            if (breed == null || breed.isEmpty()) {
                error = "No breed specified.";
                imageSrc = null;
            } else if (!Breeds.isValidBreed(breed)) {
                // =========================================================================
                // LAB 5 - WORKSHOP REFERENCE CODE 
                // Uncomment for span error handling: record error status and exception when breed search is invalid:
                //
                // Span span = tracer.spanBuilder("validateBreed").startSpan();
                // try (Scope scope = span.makeCurrent()) {
                //     span.setAttribute("breed", breed);
                //     span.setStatus(StatusCode.ERROR, "Breed validation failed");
                //     span.recordException(new IllegalArgumentException("Invalid breed: " + breed));
                // } finally {
                //     span.end();
                // }
                // =========================================================================
                error = "No breed found.";
                imageSrc = null;
            } else {
                String apiUrl = "https://dog.ceo/api/breed/" + breed + "/images/random";
                JsonObject json = fetchJson(apiUrl);
                imageSrc = json.get("message").getAsString();
            }
            
            String html = renderTemplate(imageSrc, breed, error);
            ctx.contentType("text/html");
            ctx.result(html);
        } catch (Exception e) {
            ctx.contentType("text/html");
            ctx.status(500);
            ctx.result(renderTemplateQuiet(null, null, "Error: " + e.getMessage()));
        }
    }

    /**
     * Fetches JSON from a URL using HttpURLConnection.
     */
    private static JsonObject fetchJson(String urlString) throws IOException {
        URL url = URI.create(urlString).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            return JsonParser.parseString(response.toString()).getAsJsonObject();
        } finally {
            conn.disconnect();
        }
    }

    /**
     * Extracts the breed name from a dog.ceo image URL.
     */
    private static String extractBreedFromUrl(String imageUrl) {
        
        Matcher matcher = BREED_PATTERN.matcher(imageUrl);

        if (matcher.find()) {
            return matcher.group(1);
        }
        return "unknown";

        // =========================================================================
        // LAB 5 - WORKSHOP REFERENCE CODE 
        // Replace the method code above (comment it out in favour of this code)
        // with the following to add a nested span:
        //
        // Span span = tracer.spanBuilder("extractBreedFromUrl").startSpan();
        // try (Scope scope = span.makeCurrent()) {
        //     Matcher matcher = BREED_PATTERN.matcher(imageUrl);
        //     String breed = matcher.find() ? matcher.group(1) : "unknown";
        //     span.setAttribute("breed", breed);
        //     return breed;
        // } finally {
        //     span.end();
        // }
        // =========================================================================

       
    }

    /**
     * Renders the HTML template with the dog image or error message.
     */
    private static String renderTemplate(String imageSrc, String breed, String error) throws IOException {
        String template = loadTemplate();
        
        String content;
        if (error != null) {
            content = "<p>Ruh-roh. " + escapeHtml(error) + "</p>";
        } else {
            content = "<img id=\"picture\" src=\"" + escapeHtml(imageSrc) + "\" alt=\"dog photo returned from API\">\n" +
                     "<h2>Breed: " + escapeHtml(breed) + "</h2>";
        }
        
        return template.replace("{{CONTENT}}", content);
    }

    /**
     * Renders template without throwing (for error handling).
     */
    private static String renderTemplateQuiet(String imageSrc, String breed, String error) {
        try {
            return renderTemplate(imageSrc, breed, error);
        } catch (IOException e) {
            return "<html><body><p>Ruh-roh. " + escapeHtml(error) + "</p></body></html>";
        }
    }

    /**
     * Loads the HTML template from the classpath resources.
     */
    private static String loadTemplate() throws IOException {
        try (InputStream is = AppProgramaticInstrumentation.class.getResourceAsStream("/templates/random-pet-pic.html")) {
            if (is == null) {
                throw new IOException("Template not found");
            }
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    /**
     * Escapes HTML special characters to prevent XSS.
     */
    private static String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                  .replace("<", "&lt;")
                  .replace(">", "&gt;")
                  .replace("\"", "&quot;");
    }
}
