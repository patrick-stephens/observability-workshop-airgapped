package io.chronosphere;

import io.javalin.Javalin;
import org.junit.jupiter.api.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for the App HTTP server.
 * 
 * These tests start the server on a test port and make HTTP requests
 * to verify the endpoints work correctly.
 */
class AppTest {

    private static final int TEST_PORT = 19999;
    private static Javalin app;

    @BeforeAll
    static void startServer() {
        app = App.createApp();
        app.start(TEST_PORT);
    }

    @AfterAll
    static void stopServer() {
        if (app != null) {
            app.stop();
        }
    }

    // ==================== Index Handler Tests ====================

    @Test
    @DisplayName("GET / returns page view counter")
    void indexHandler_returnsPageViewCounter() throws IOException {
        String response = httpGet("/");
        assertTrue(response.contains("This webpage has been viewed"));
        assertTrue(response.contains("times"));
    }

    @Test
    @DisplayName("GET / increments counter on each request")
    void indexHandler_incrementsCounter() throws IOException {
        String response1 = httpGet("/");
        String response2 = httpGet("/");
        
        // Extract the numbers from both responses
        int count1 = extractNumber(response1);
        int count2 = extractNumber(response2);
        
        assertEquals(count1 + 1, count2, "Counter should increment by 1");
    }

    @Test
    @DisplayName("POST / returns 404 (no POST handler defined)")
    void indexHandler_postReturns404() throws IOException {
        int statusCode = httpPost("/", "");
        assertEquals(404, statusCode);
    }

    // ==================== RollDice Handler Tests ====================

    @Test
    @DisplayName("GET /rolldice returns number between 1 and 6")
    void rollDiceHandler_returnsValidDiceRoll() throws IOException {
        for (int i = 0; i < 20; i++) {
            String response = httpGet("/rolldice");
            int roll = Integer.parseInt(response.trim());
            assertTrue(roll >= 1 && roll <= 6, "Dice roll should be between 1 and 6, got: " + roll);
        }
    }

    @Test
    @DisplayName("POST /rolldice returns 404 (no POST handler defined)")
    void rollDiceHandler_postReturns404() throws IOException {
        int statusCode = httpPost("/rolldice", "");
        assertEquals(404, statusCode);
    }

    // ==================== Doggo Handler Tests ====================

    @Test
    @DisplayName("GET /doggo returns HTML with dog image")
    @Tag("network")
    void doggoHandler_getReturnsHtmlWithImage() throws IOException {
        String response = httpGet("/doggo");
        assertTrue(response.contains("<!DOCTYPE html>"));
        assertTrue(response.contains("<img"));
        assertTrue(response.contains("dog.ceo"));
        assertTrue(response.contains("Breed:"));
    }

    @Test
    @DisplayName("POST /doggo with valid breed returns image")
    @Tag("network")
    void doggoHandler_postWithValidBreedReturnsImage() throws IOException {
        String response = httpPostBody("/doggo", "breed-search=husky");
        assertTrue(response.contains("<!DOCTYPE html>"));
        assertTrue(response.contains("<img"));
        assertTrue(response.contains("husky"));
    }

    @Test
    @DisplayName("POST /doggo with invalid breed returns error")
    @Tag("network")
    void doggoHandler_postWithInvalidBreedReturnsError() throws IOException {
        String response = httpPostBody("/doggo", "breed-search=unicorn");
        assertTrue(response.contains("Ruh-roh"));
        assertTrue(response.contains("No breed found"));
    }

    @Test
    @DisplayName("POST /doggo with empty breed returns error")
    @Tag("network")
    void doggoHandler_postWithEmptyBreedReturnsError() throws IOException {
        String response = httpPostBody("/doggo", "breed-search=");
        assertTrue(response.contains("Ruh-roh"));
    }

    // ==================== Helper Methods ====================

    private String httpGet(String path) throws IOException {
        URL url = URI.create("http://localhost:" + TEST_PORT + path).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line).append("\n");
            }
            return response.toString();
        } finally {
            conn.disconnect();
        }
    }

    private int httpPost(String path, String body) throws IOException {
        URL url = URI.create("http://localhost:" + TEST_PORT + path).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        
        int statusCode = conn.getResponseCode();
        conn.disconnect();
        return statusCode;
    }

    private String httpPostBody(String path, String body) throws IOException {
        URL url = URI.create("http://localhost:" + TEST_PORT + path).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line).append("\n");
            }
            return response.toString();
        } finally {
            conn.disconnect();
        }
    }

    private int extractNumber(String text) {
        // Extract the number from "This webpage has been viewed X times"
        String[] parts = text.split(" ");
        for (String part : parts) {
            try {
                return Integer.parseInt(part);
            } catch (NumberFormatException ignored) {
            }
        }
        return -1;
    }
}
