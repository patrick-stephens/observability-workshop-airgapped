package io.chronosphere;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Breeds class.
 */
class BreedsTest {

    @Test
    @DisplayName("Valid breed returns true")
    void isValidBreed_withValidBreed_returnsTrue() {
        assertTrue(Breeds.isValidBreed("husky"));
        assertTrue(Breeds.isValidBreed("corgi"));
        assertTrue(Breeds.isValidBreed("labrador"));
        assertTrue(Breeds.isValidBreed("poodle"));
    }

    @Test
    @DisplayName("Valid breed is case-insensitive")
    void isValidBreed_isCaseInsensitive() {
        assertTrue(Breeds.isValidBreed("HUSKY"));
        assertTrue(Breeds.isValidBreed("Husky"));
        assertTrue(Breeds.isValidBreed("HuSkY"));
        assertTrue(Breeds.isValidBreed("CORGI"));
    }

    @Test
    @DisplayName("Invalid breed returns false")
    void isValidBreed_withInvalidBreed_returnsFalse() {
        assertFalse(Breeds.isValidBreed("unicorn"));
        assertFalse(Breeds.isValidBreed("cat"));
        assertFalse(Breeds.isValidBreed("dragon"));
        assertFalse(Breeds.isValidBreed(""));
    }

    @Test
    @DisplayName("Breeds set contains expected breeds")
    void breeds_containsExpectedBreeds() {
        assertTrue(Breeds.BREEDS.contains("affenpinscher"));
        assertTrue(Breeds.BREEDS.contains("wolfhound"));
        assertTrue(Breeds.BREEDS.contains("shiba"));
        assertTrue(Breeds.BREEDS.contains("dalmatian"));
    }

    @Test
    @DisplayName("Breeds set has expected size")
    void breeds_hasExpectedSize() {
        // Should have 99 breeds based on the breeds list
        assertEquals(99, Breeds.BREEDS.size());
    }
}

