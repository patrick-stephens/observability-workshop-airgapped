# Simple OpenTelemetry Tracing Instrumentation Java Example

This is a simple Java based example application for demonstrating OpenTelemetry tracing instrumentation for developers.

Requirements: **Java 21** (LTS), Maven

> **Note:** Java 21 is required for full OpenTelemetry auto-instrumentation compatibility. The application uses Javalin (built on Jetty) which is auto-instrumented by the OpenTelemetry Java agent.

## Build example Java application

```shell
mvn clean install

java -jar target/java-instrumentation-demo-1.0-SNAPSHOT-with-dependencies.jar
```

Creating a container image (use podman or docker):

```shell
# Build the container image.
podman build -t java-instrumentation-demo -f Buildfile

# Run image mapping from 9999 local machine port to the
# exposed 9999 port on running container.
podman run --rm --name jid -p 9999:9999 java-instrumentation-demo
```

## Running application

The application provides several endpoints to demonstrate tracing:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Page view counter |
| `/rolldice` | GET | Random dice roll (1-6) |
| `/doggo` | GET | Random dog image from dog.ceo API |
| `/doggo` | POST | Search for specific breed image |

Server runs on: <http://localhost:9999>

## Testing the endpoints

View the index page counter:

```shell
curl http://localhost:9999/
```

```text
This webpage has been viewed 1 times
```

Roll the dice:

```shell
curl http://localhost:9999/rolldice
```

```text
4
```

Get a random dog image:

```shell
curl http://localhost:9999/doggo
```

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Pet Pic</title>
  </head>
  <body>
    <img id="picture" src="https://images.dog.ceo/breeds/husky/image.jpg" alt="dog photo returned from API">
    <h2>Breed: husky</h2>
    <form class="form-search" method="POST">
      ...
    </form>
  </body>
</html>
```

Search for a specific breed:

```shell
curl -X POST -d "breed-search=corgi" http://localhost:9999/doggo
```

## Implementation details

The application uses [Javalin](https://javalin.io/), a lightweight HTTP framework built on Jetty. This enables automatic OpenTelemetry instrumentation for all HTTP endpoints.

### Index handler (`/`)

Demonstrates a simple page view counter using an `AtomicInteger` for thread-safe counting:

```java
private static void handleIndex(Context ctx) {
    int hits = HITS.incrementAndGet();
    ctx.result("This webpage has been viewed " + hits + " times");
}
```

### Roll dice handler (`/rolldice`)

Returns a random number between 1 and 6:

```java
private static void handleRollDice(Context ctx) {
    int roll = RANDOM.nextInt(6) + 1;
    ctx.result(String.valueOf(roll));
}
```

### Doggo handler (`/doggo`)

Makes external HTTP calls to the dog.ceo API:

```java
private static void handleDoggoGet(Context ctx) {
    String apiUrl = "https://dog.ceo/api/breeds/image/random";
    JsonObject json = fetchJson(apiUrl);
    String imageSrc = json.get("message").getAsString();
    // ... render HTML template
}
```

This demonstrates:

- External HTTP calls (outbound tracing)
- JSON parsing with Gson
- Form data handling
- Error handling and validation
- HTML template rendering

## Project structure

```text
src/main/java/io/chronosphere/
├── App.java       # Main class with HTTP server and handlers
└── Breeds.java    # Valid dog breeds list for validation

src/main/resources/templates/
└── random-pet-pic.html   # HTML template for dog images
```

## OpenTelemetry instrumentation

This application is designed to be instrumented with OpenTelemetry. You can add automatic instrumentation using the OpenTelemetry Java Agent:

```shell
# Download the OpenTelemetry Java Agent (v2.30.0)
curl -L -o opentelemetry-javaagent-2.30.0.jar \
  https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/download/v2.30.0/opentelemetry-javaagent.jar
```

### Quick test with console logging

```shell
java -javaagent:opentelemetry-javaagent-2.30.0.jar \
     -Dotel.service.name=java-demo \
     -Dotel.traces.exporter=logging \
     -Dotel.metrics.exporter=none \
     -Dotel.logs.exporter=none \
     -jar target/java-instrumentation-demo-1.0-SNAPSHOT-with-dependencies.jar
```

### Send traces to an OTLP endpoint

```shell
java -javaagent:opentelemetry-javaagent-2.30.0.jar \
     -Dotel.service.name=java-demo \
     -Dotel.traces.exporter=otlp \
     -Dotel.exporter.otlp.endpoint=http://localhost:4317 \
     -jar target/java-instrumentation-demo-1.0-SNAPSHOT-with-dependencies.jar
```

## Running metrics collection

Lab 6 adds an OpenTelemetry metrics SDK with a Prometheus exporter on port 9464.
Prometheus itself is built from `Buildfile-prom`, which bakes in both scrape
configs plus the feature flags needed to store and plot exemplars:

```shell
podman build -t java-demo-prometheus:v3.13.1 -f Buildfile-prom

# Podman path: application runs on the host, Prometheus scrapes
# host.containers.internal:9464 (the default config).
podman run --rm -ti --name prometheus -p 9090:9090 java-demo-prometheus:v3.13.1
```

## Manual instrumentation on k3s

Lab 5 enriches spans by hand and views them in Jaeger. On the Kubernetes (k3s)
path the application and Jaeger run as two containers in a single pod, so the
Java Agent's default OTLP endpoint (`http://localhost:4318`) reaches Jaeger with
no configuration at all:

```shell
mvn clean install -f pom-programatic-instrumentation.xml
podman build -t java-demo:manual -f Buildfile-manual
podman save localhost/java-demo:manual -o java-demo-manual.tar
nerdctl --namespace k8s.io load -i java-demo-manual.tar

kubectl apply -f k8s/manual-pod.yaml
kubectl wait --for=condition=Ready pod/java-demo-manual --timeout=180s
kubectl port-forward pod/java-demo-manual 9999:9999 16686:16686
```

Repeat the build, save, load and re-apply after every source change.

### Kubernetes (k3s) path

On a local Rancher Desktop k3s cluster the application and Prometheus run as two
containers in a single pod, so Prometheus scrapes `localhost:9464` instead -
`host.containers.internal` does not resolve from inside a pod:

```shell
podman build -t java-demo:metrics -f Buildfile
podman save localhost/java-demo:metrics -o java-demo-metrics.tar
podman save localhost/java-demo-prometheus:v3.13.1 -o java-demo-prometheus.tar

nerdctl --namespace k8s.io load -i java-demo-metrics.tar
nerdctl --namespace k8s.io load -i java-demo-prometheus.tar

kubectl apply -f k8s/metrics-pod.yaml
kubectl wait --for=condition=Ready pod/java-demo-metrics --timeout=180s
kubectl port-forward pod/java-demo-metrics 9999:9999 9090:9090
```

## Resources

- [OpenTelemetry Java Documentation](https://opentelemetry.io/docs/languages/java/)
- [OpenTelemetry Java Agent](https://github.com/open-telemetry/opentelemetry-java-instrumentation)
- [Dog CEO API](https://dog.ceo/dog-api/)


## Released versions

See the tagged releases for the following versions of the product:

- v1.1 - Supporting Java 21, OpenTelemetry Java Agent 2.30, OpenTelemetry SDK 1.65, Prometheus v3.13.1, 
         and a Kubernetes (k3s) path for the OpenTelemetry for Developers Workshop.

- v1.0 - Supporting Java 21, OpenTelemetry Java Agent 2.13.0, and OpenTelemetry for Developers Workshop.
